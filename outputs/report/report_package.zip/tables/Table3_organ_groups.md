**Table 3.** Septic patients by organ group (partial SOFA, window 24 h before to 6 h after the sepsis label) and the share warned in time by LightGBM at the balanced setting, with Wilson 95% CIs. Attributable (not Unattributable): 51.5% overall; gate (50% in each hospital) passed.

| Organ group | All, n (%) | Warned in time, all, % (95% CI) | Hospital A, n (%) | Warned in time, A, % (95% CI) | Hospital B, n (%) | Warned in time, B, % (95% CI) |
| --- | --- | --- | --- | --- | --- | --- |
| Lungs | 128 (5.1%) | 59.2 (49.6 to 68.2) | 94 (5.9%) | 65.8 (54.6 to 75.5) | 34 (3.7%) | 40.7 (24.5 to 59.3) |
| Clotting | 118 (4.7%) | 45.0 (35.6 to 54.8) | 66 (4.2%) | 54.5 (41.5 to 67.0) | 52 (5.7%) | 33.3 (21.4 to 47.9) |
| Liver | 17 (0.7%) | 30.8 (12.7 to 57.6) | 5 (0.3%) | 50.0 (15.0 to 85.0) | 12 (1.3%) | 22.2 (6.3 to 54.7) |
| Circulation | 604 (24.1%) | 46.7 (42.4 to 51.1) | 417 (26.3%) | 48.0 (42.8 to 53.2) | 187 (20.3%) | 43.6 (35.9 to 51.6) |
| Kidneys | 85 (3.4%) | 42.4 (31.2 to 54.4) | 46 (2.9%) | 42.9 (28.0 to 59.1) | 39 (4.2%) | 41.9 (26.4 to 59.2) |
| Multi-organ | 338 (13.5%) | 51.6 (45.5 to 57.7) | 184 (11.6%) | 53.6 (45.3 to 61.6) | 154 (16.8%) | 49.1 (40.1 to 58.2) |
| Unattributable | 1216 (48.5%) | 38.1 (35.1 to 41.2) | 775 (48.8%) | 39.0 (35.2 to 42.9) | 441 (48.0%) | 36.7 (31.9 to 41.8) |
